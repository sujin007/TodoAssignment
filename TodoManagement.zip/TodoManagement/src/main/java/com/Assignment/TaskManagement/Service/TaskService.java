package com.Assignment.TaskManagement.Service;

import java.util.List;

import com.Assignment.TaskManagement.Entity.Task;

public interface TaskService {

	public Task saveToDoTask(Task task);
	public List<Task> fetchTasksByName(String string);
	public Task updateTask(long id, Task task);
	public List<Task> fetchAllTasks();
	public void deleteTask(long id);
	public void deleteTaskByName(String name);
	public void deleteAlltasks();
	public Task closeTask(Boolean isClosed, Task task);

}
