package com.Assignment.TaskManagement.Entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private long id;
	private String userName;
	@NotBlank(message = "Task name should not be null")
	private String taskName;
	private String taskDescription;
	private String Status;
	private Date lastUpdatedDate;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public Task(long id, String userName, String taskName, String taskDescription, Date lastUpdatedDate) {
		super();
		this.id = id;
		this.userName = userName;
		this.taskName = taskName;
		this.taskDescription = taskDescription;
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public Task() {
		super();
	}
	@Override
	public String toString() {
		return "TaskToDo [id=" + id + ", userName=" + userName + ", taskName=" + taskName + ", taskDescription="
				+ taskDescription + ", lastUpdatedDate=" + lastUpdatedDate + "]";
	}
	
	
}
