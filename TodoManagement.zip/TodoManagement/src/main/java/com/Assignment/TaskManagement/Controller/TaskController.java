package com.Assignment.TaskManagement.Controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.Assignment.TaskManagement.Entity.Task;
import com.Assignment.TaskManagement.Service.TaskService;

@RestController
public class TaskController {

	@Autowired
	private TaskService taskService;

	private final Logger LOGGER = LoggerFactory.getLogger(TaskController.class);

	@PostMapping("/tasks/add-tasks")
	public Task saveToDoTask(@RequestBody Task task) {
		return taskService.saveToDoTask(task);
	}

	@GetMapping("/task")
	public List<Task> fetchAllTasks() {
		return taskService.fetchAllTasks();
	};

	@GetMapping("/tasks/view-tasks/{username}")
	public List<Task> fetchTasksByUserName(@PathVariable("username") String username) {
		return taskService.fetchTasksByName(username);
	}

	@PostMapping("/tasks/close-tasks/{isClosed}")
	public Task closeTask(@PathVariable("isClosed") Boolean isClosed, @RequestBody Task task) {
		return taskService.closeTask(isClosed, task);
	}

	@PutMapping("/tasks/edit-task/{id}")
	public Task updateTask(@PathVariable("id") Long id, @RequestBody Task task) {
		Task updatedTask = taskService.updateTask(id, task);
		LOGGER.info("updated successfully");
		return updatedTask;
	}

	@DeleteMapping("/tasks/delete-task/{id}")
	public void deleteTask(@PathVariable("id") Long id) {
		taskService.deleteTask(id);
		LOGGER.info("deleted successfully");
	}
	
	@DeleteMapping("/tasks/delete-task/name/{name}")
	public void deleteTaskByName(@PathVariable("name") String name) {
		taskService.deleteTaskByName(name);
		LOGGER.info("deleted successfully");
	}

	@DeleteMapping("/tasks/deleteall-task")
	public void deleteAllTasks() {
		taskService.deleteAlltasks();
	}

}
