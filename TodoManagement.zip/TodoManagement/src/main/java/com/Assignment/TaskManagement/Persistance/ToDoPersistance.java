package com.Assignment.TaskManagement.Persistance;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Assignment.TaskManagement.Entity.Task;

@Repository
public interface ToDoPersistance extends JpaRepository<Task, Long> {

	public List<Task> findAllByUserNameIgnoreCase(String name);

	public void deleteByUserNameIgnoreCase(String name);

}


