package com.Assignment.TaskManagement.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Assignment.TaskManagement.Entity.Task;
import com.Assignment.TaskManagement.Persistance.ToDoPersistance;

@Service
public class TaskServiceImpl implements TaskService {

	private static final String CLOSED = "Closed";
	private static final String PENDING = "Pending";
	
	@Autowired
	private ToDoPersistance doPersistance;

	@Override
	public Task saveToDoTask(Task task) {
		task.setLastUpdatedDate(getCurrentDate());
		task.setStatus("Pending");
		return doPersistance.save(task);

	}

	@Override
	public List<Task> fetchTasksByName(String name) {
		return doPersistance.findAllByUserNameIgnoreCase(name);
	}

	@Override
	public Task updateTask(long id, Task task) {
		Task taskToDo = doPersistance.findById(id).get();
		if (Objects.nonNull(taskToDo.getUserName()) && "".equals(taskToDo.getUserName())) {
			taskToDo.setUserName(task.getUserName());
		}
		if (Objects.nonNull(taskToDo.getTaskName()) && "".equals(taskToDo.getTaskName())) {
			taskToDo.setTaskName(task.getTaskName());
		}
		taskToDo.setTaskDescription(task.getTaskDescription());
		taskToDo.setLastUpdatedDate(getCurrentDate());
		return doPersistance.save(taskToDo);
	}

	
	@Override
	public Task closeTask(Boolean isClosed, Task task) {
		Task taskToDo = doPersistance.findById(task.getId()).get();
		String Status = (isClosed)? CLOSED: PENDING;
		taskToDo.setStatus(Status);
		return doPersistance.save(taskToDo);
		
	}
	
	@Override
	public List<Task> fetchAllTasks() {
		return doPersistance.findAll();
	}

	@Override
	public void deleteTask(long id) {
		doPersistance.deleteById(id);
	}

	@Override
	public void deleteTaskByName(String name) {
		doPersistance.deleteByUserNameIgnoreCase(name);
	}

	@Override
	public void deleteAlltasks() {
		doPersistance.deleteAll();
	}

	private Date getCurrentDate() {
    	 return new java.sql.Date(System.currentTimeMillis());  
	}

	

}
